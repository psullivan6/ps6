<div class="g_row">
	
	<div class="g_col S_3 S4_4 M_6 L_9 XL_12">
		
		<footer>
			
			<p>&copy;2013 &middot; Patrick Sullivan &middot; 44.060901&deg;, 123.061756&deg;</p><!-- http://creativecommons.org/ -->
			
		</footer> <!-- /footer -->
		
	</div> <!-- /.g_col -->
	
</div> <!-- /.g_row -->