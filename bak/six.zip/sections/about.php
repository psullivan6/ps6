<div class="g_row">
	
	<div class="g_col g_off S_off S4_off M_1 L_2 XL_3">&nbsp;</div>
	
	<div class="g_col S3_3 S4_4 M_4 L_5 XL_6">
		
		<div id="about" class="section about">
			
			<h1 class="h2">I'm Patrick Sullivan and I'm a</h1>
			
			<article>
				
				<div class="titles">
					
					<ul>
						
						<li><h2 class="h1-u">Web Designer</h2></li>
						
						<li><h2 class="h1-u">User Interface Designer</h2></li>
						
						<li><h2 class="h1-u">Front-End Web Developer</h2></li>
						
						<li><h2 class="h1-u">Graphic Designer</h2></li>
						
						<li><h2 class="h1-u">Copywriter</h2></li>
						
						<li><h2 class="h1-u">Copy Maching Technician</h2></li>
						
					</ul>
					
				</div>
				
				<p class="h2">I also like being outside; drinking beer; watching the Giants, 49<sup>ers</sup>, Ducks, or Warriors; and hanging with my awesome girlfriend.</p>
				
			</article>
			
		</div> <!-- /#about -->
		
	</div> <!-- /.g_col -->
	
	<div class="g_col g_off S_off  S4_off M_1 L_2 XL_3">&nbsp;</div>
	
</div> <!-- /.g_row -->