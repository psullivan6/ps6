<article>
	
	<div id="post-<?php the_ID(); ?>" <?php post_class('content'); ?>>
		
		<?php if (is_search()): ?>
			
			<div class="item-summary">
				
				<?php the_excerpt(); ?>
				
			</div> <!-- /.item-summary -->
			
		<?php else: ?>
			
			<header class="transition">
				
				<h1 class="h1-u transition">
					
					<a href="<?php the_permalink(); ?>" title="<?php printf(esc_attr__('%s', 'six'), the_title_attribute('echo=0')); ?>" rel="bookmark"><?php the_title(); ?></a>
					
				</h1>
				
			</header>
			
			<!-- ==================================== -->
			
			<a class="item-content" href="<?php the_permalink(); ?>" title="<?php printf(esc_attr__('%s', 'six'), the_title_attribute('echo=0')); ?>" rel="bookmark">
				
				<?php if ( has_post_thumbnail()) : // Check if Thumbnail exists ?>
					
					<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
						
						<?php the_post_thumbnail(); // Fullsize image for the single post ?>
						
					</a>
					
				<?php else: ?>
					
					<?php the_content(__('', 'six')); ?>
					
					<?php wp_link_pages(array('before' => '<div class="page-link">' . __('Pages:', 'six'), 'after' => '</div>')); ?>
					
				<?php endif; ?>
				
			</a> <!-- /.item-content -->
			
		<?php endif; ?>
		
	</div> <!-- /#post-<?php the_ID(); ?> -->
	
</article>