<div class="g_row">
	
	<div class="g_col S_3 S4_4 M_6 L_9 XL_12">
		
		<header>
			
			<div class="logo">
				
				<a href="http://psullivan6.com/ps6">
					
					<img src="http://assets.psullivan6.com/i/psullivan6.svg">
					
				</a>
				
			</div>
			
			<nav>
				
				<div id="nav">
					
					<ul>
						
						<?php if (is_single()): ?>
							
							<li><a href="http://psullivan6.com/ps6/#work" target="_self" class="scroll">Work</a></li>
							
							<li><a target="_blank" href="http://psullivan6.com/Patrick-Sullivan_resume.pdf" target="_self" class="scroll">Resum&eacute;</a></li>
							
							<li><a href="http://psullivan6.com/ps6/#contact" target="_self" class="scroll">Get in Touch</a></li>
							
						<?php else: ?>
							
							<li><a href="#work" target="_self" class="scroll">Work</a></li>
							
							<li><a target="_blank" href="http://psullivan6.com/Patrick-Sullivan_resume.pdf" target="_self" class="scroll">Resum&eacute;</a></li>
							
							<li><a href="#contact" target="_self" class="scroll">Get in Touch</a></li>
							
						<?php endif; ?>
						
					</ul>
					
				</div> <!-- /#nav -->
				
			</nav>
			
			<div class="clear"></div>
			
		</header>
		
	</div> <!-- /.g_col -->
	
</div> <!-- /.g_row -->